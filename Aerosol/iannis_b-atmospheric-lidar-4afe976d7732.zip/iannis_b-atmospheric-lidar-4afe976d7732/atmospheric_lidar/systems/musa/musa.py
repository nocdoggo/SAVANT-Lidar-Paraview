from ...licel import LicelLidarMeasurement
from ..ciao import CiaoMixin

class MusaLidarMeasurement(CiaoMixin, LicelLidarMeasurement):
    pass
